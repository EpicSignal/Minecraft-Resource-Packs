-- Shortsight Fix --



-- INCLUDES --

Fixes various blocks (such as flora) from rendering transparently when viewed from a distance